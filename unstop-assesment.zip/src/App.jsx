import Dashboard from "./Dashboard/Dashboard.Component";
import MobileNavbar from "./Mobile-View/Mobile.Component";

function App() {
  return (
    <>
      <Dashboard />
      <MobileNavbar />
    </>
  );
}

export default App;
