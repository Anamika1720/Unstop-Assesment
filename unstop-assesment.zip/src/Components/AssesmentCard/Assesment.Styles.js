import styled from "styled-components";

export const Container = styled.div`
  display: flex;
  gap: 20px;
`;

export const Card = styled.div`
  background: #ffffff;
  padding: 16px;
  border-radius: 12px;
  gap: 10px;
  border: 1px solid #e0e0e0;
  width: 94%;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

export const IconWrapper = styled.span`
  font-size: 24px;
  color: #7a7adb;
  padding: 10px;
  border-radius: 10px;
  display: inline-block;
`;

export const Title = styled.div`
  font-size: 20px;
  font-weight: bold;
  color: #333;
  margin-top: 10px;

  @media (max-width: 768px) {
    font-size: 18px;
  }
`;

export const Subtitle = styled.div`
  font-size: 14px;
  color: #666;
  display: flex;
  align-items: center;
  gap: 5px;
  margin-top: 5px;

  @media (max-width: 768px) {
    font-size: 12px;
  }
`;

export const Info = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

export const ShareButton = styled.button`
  display: flex;
  align-items: center;
  gap: 5px;
  background: #e7f0ff;
  color: #007bff;
  border: none;
  padding: 5px 10px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 12px;
  font-weight: bold;
  transition: background 0.3s;

  &:hover {
    background: #d0e1ff;
  }
`;

export const Avatar = styled.div`
  width: 30px;
  height: 30px;
  background: #7a7adb;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: bold;
`;

export const Options = styled.span`
  position: absolute;
  top: 10px;
  right: 10px;
  cursor: pointer;
  color: #888;
`;
