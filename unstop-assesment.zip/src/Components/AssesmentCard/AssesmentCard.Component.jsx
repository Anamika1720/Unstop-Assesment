import {
  Avatar,
  Card,
  IconWrapper,
  Info,
  Options,
  ShareButton,
  Subtitle,
  Title,
} from "./Assesment.Styles";

const AssessmentCard = ({ title, date }) => {
  return (
    <Card>
      <IconWrapper className="material-icons">work</IconWrapper>
      <Title>{title}</Title>
      <Subtitle>
        <strong>Job</strong>{" "}
        <span className="material-icons" style={{ fontSize: "14px" }}>
          event
        </span>{" "}
        {date}
      </Subtitle>
      <Info>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <div>
            00 <span style={{ fontSize: "10px" }}>Duration</span>
          </div>
          <div>
            00 <span style={{ fontSize: "10px" }}>Questions</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: "5px", alignItems: "center" }}>
          <ShareButton>
            <span className="material-icons" style={{ fontSize: "14px" }}>
              share
            </span>
            Share
          </ShareButton>
          <Avatar>LP</Avatar>
        </div>
      </Info>
    </Card>
  );
};

export default AssessmentCard;
