import styled from "styled-components";

export const CardContainer = styled.div`
  background: #f6f8fa;
  padding: 16px;
  border-radius: 12px;
  gap: 10px;
  border: 1px solid #e0e0e0;
  width: 94%;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

export const PlusIcon = styled.div`
  font-size: 40px;
  color: #007bff;
`;

export const Title = styled.h3`
  font-size: 18px;
  font-weight: bold;
  margin: 10px 0;
`;

export const Text = styled.p`
  font-size: 14px;
  color: #666;
`;
