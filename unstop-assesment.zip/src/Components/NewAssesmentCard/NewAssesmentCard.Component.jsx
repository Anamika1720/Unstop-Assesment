import { CardContainer, PlusIcon, Text, Title } from "./NewAssesment.Styles";

const NewAssessmentCard = ({ onClick }) => {
  return (
    <CardContainer onClick={onClick}>
      <PlusIcon>+</PlusIcon>
      <Title>New Assessment</Title>
      <Text>
        From here you can add questions of multiple types like MCQs, subjective
        (text or paragraph)!
      </Text>
    </CardContainer>
  );
};

export default NewAssessmentCard;
