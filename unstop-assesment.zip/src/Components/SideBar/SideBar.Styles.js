import styled from "styled-components";

export const SidebarContainer = styled.div`
  width: 140;
  height: 992;
  top: 2px;
  padding: 10px 20px 20px 30px;
  gap: 10px;
  background: #ffffff;
`;

export const Container = styled.div`
  width: 90;
  height: 361;
  gap: 16px;
`;

export const Container1 = styled.div`
  width: 90;
  height: 225;
  padding-bottom: 10px;
  gap: 2px;
`;

export const Container2 = styled.div`
  width: 90;
  height: 104;
  gap: 6px;
`;

export const CloseButton = styled.button`
  background: none;
  border: none;
  cursor: pointer;
  align-self: flex-end;
  font-size: 24px;
  margin-bottom: 20px;
  color: #333;
`;

export const MenuItem = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px;
  cursor: pointer;
  border-radius: 8px;
  background: ${(props) => (props.active ? "#E0ECFF" : "transparent")};
  border: ${(props) => (props.active ? "1px solid #005FCC" : "none")};
`;

export const Icon = styled.span`
  margin-right: 10px;
  font-size: 24px;
  color: #333;
`;

export const Text = styled.span`
  font-family: Inter;
  font-weight: 500;
  font-size: 12px;
  line-height: 16.8px;
  letter-spacing: 0px;
  width: 63;
  height: 17;
`;

export const Text1 = styled.span`
  font-family: Inter;
  font-weight: 500;
  font-size: 12px;
  line-height: 16.8px;
  letter-spacing: 0px;
  width: 63;
  height: 17;
`;
